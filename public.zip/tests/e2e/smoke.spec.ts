import { expect, test } from '@playwright/test';

test('landing page loads and switches to Arabic RTL', async ({ page }) => {
  await page.goto('/');

  await expect(page.getByRole('heading', { level: 1 })).toContainText('Apprends mieux');
  await expect(page.getByRole('link', { name: 'Créer mon compte' }).first()).toBeVisible();

  await page.getByLabel("Langue de l'interface").first().selectOption('ar');

  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  await expect(page.locator('html')).toHaveAttribute('lang', 'ar');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('تعلّم بذكاء');
});

test('theme toggle switches between dark and light', async ({ page }) => {
  await page.goto('/');

  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await page.getByRole('button', { name: 'Activer le thème clair' }).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  await expect(page.getByRole('button', { name: 'Activer le thème sombre' })).toBeVisible();
});

test('auth page reports the missing Supabase configuration instead of failing silently', async ({
  page,
}) => {
  await page.goto('/auth');

  await expect(page.getByText('Configuration Supabase manquante')).toBeVisible();
  await expect(page.getByText('VITE_SUPABASE_URL')).toBeVisible();
  await expect(page.getByText('VITE_SUPABASE_ANON_KEY')).toBeVisible();
});

test('unknown routes show the not-found page', async ({ page }) => {
  await page.goto('/cette-page-nexiste-pas');

  await expect(page.getByRole('heading', { name: "Cette page n'existe pas." })).toBeVisible();
  await expect(
    page.locator('#main-content').getByRole('link', { name: "Retour à l'accueil" }),
  ).toBeVisible();
});
