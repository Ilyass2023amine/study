import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';

import { AppShell } from '@/components/layout/app-shell';
import { MarketingLayout } from '@/components/layout/marketing-layout';
import { PageLoader } from '@/components/layout/page-loader';
import { RequireAuth } from '@/features/auth/require-auth';

const LandingPage = lazy(() => import('@/pages/landing-page'));
const AuthPage = lazy(() => import('@/pages/auth-page'));
const AuthCallbackPage = lazy(() => import('@/pages/auth-callback-page'));
const AccountPage = lazy(() => import('@/pages/account-page'));
const PrivacyPage = lazy(() => import('@/pages/privacy-page'));
const NotFoundPage = lazy(() => import('@/pages/not-found-page'));

export function AppRouter() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        <Route element={<MarketingLayout />}>
          <Route index element={<LandingPage />} />
          <Route path="privacy" element={<PrivacyPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>

        <Route path="auth" element={<AuthPage />} />
        <Route path="auth/callback" element={<AuthCallbackPage />} />

        <Route element={<RequireAuth />}>
          <Route element={<AppShell />}>
            <Route path="account" element={<AccountPage />} />
          </Route>
        </Route>
      </Routes>
    </Suspense>
  );
}
