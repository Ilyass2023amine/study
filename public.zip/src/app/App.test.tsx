import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { App } from '@/app/App';

describe('App', () => {
  it('renders the French landing page without a Supabase configuration', async () => {
    render(<App />);

    expect(
      await screen.findByRole('heading', { level: 1, name: /Apprends mieux/ }),
    ).toBeInTheDocument();
    expect(screen.getAllByRole('link', { name: 'Créer mon compte' }).length).toBeGreaterThan(0);
  });

  it('renders a not-found page for an unknown route', async () => {
    window.history.pushState({}, '', '/une-page-inconnue');

    render(<App />);

    expect(
      await screen.findByRole('heading', { name: "Cette page n'existe pas." }),
    ).toBeInTheDocument();
    window.history.pushState({}, '', '/');
  });
});
