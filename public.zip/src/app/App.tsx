import { BrowserRouter } from 'react-router-dom';

import { OfflineBanner } from '@/components/layout/offline-banner';
import { SkipLink } from '@/components/layout/skip-link';

import { ErrorBoundary } from './error-boundary';
import { AppProviders } from './providers';
import { AppRouter } from './router';

export function App() {
  return (
    <AppProviders>
      <BrowserRouter useTransitions={false}>
        <SkipLink />
        <OfflineBanner />
        <ErrorBoundary>
          <AppRouter />
        </ErrorBoundary>
      </BrowserRouter>
    </AppProviders>
  );
}
