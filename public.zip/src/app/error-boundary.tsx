import { RotateCcw } from 'lucide-react';
import { Component, type ErrorInfo, type ReactNode } from 'react';
import { useTranslation } from 'react-i18next';

import { BrandMark } from '@/components/brand/brand-mark';
import { Button } from '@/components/ui/button';

function AppCrashFallback() {
  const { t } = useTranslation();

  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-4 px-4 text-center">
      <BrandMark size={52} withWordmark={false} />
      <h1 className="text-2xl font-bold text-fg">{t('errors.unexpectedTitle')}</h1>
      <p className="max-w-md text-sm leading-6 text-muted">{t('errors.unexpectedBody')}</p>
      <Button className="mt-2" onClick={() => window.location.reload()}>
        <RotateCcw className="size-4" aria-hidden="true" />
        {t('errors.reload')}
      </Button>
    </main>
  );
}

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  override state: ErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  override componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('Unhandled application error', error, info.componentStack);
  }

  override render(): ReactNode {
    if (this.state.hasError) {
      return <AppCrashFallback />;
    }
    return this.props.children;
  }
}
