import type { User } from '@supabase/supabase-js';

export function getUserDisplayName(user: User | null): string {
  const metadataName: unknown = user?.user_metadata['display_name'];
  if (typeof metadataName === 'string' && metadataName.trim()) {
    return metadataName.trim();
  }
  if (user?.email) {
    return user.email.split('@')[0] ?? user.email;
  }
  return 'StudyVerse';
}
