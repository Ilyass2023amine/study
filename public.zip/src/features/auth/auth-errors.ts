import type { AuthError } from '@supabase/supabase-js';

export type AuthErrorTranslationKey =
  | 'auth.errors.invalidCredentials'
  | 'auth.errors.emailNotConfirmed'
  | 'auth.errors.alreadyRegistered'
  | 'auth.errors.weakPassword'
  | 'auth.errors.rateLimited'
  | 'auth.errors.serviceUnavailable'
  | 'auth.errors.generic';

export function isAuthError(value: unknown): value is AuthError {
  return (
    typeof value === 'object' &&
    value !== null &&
    'message' in value &&
    typeof value.message === 'string' &&
    'status' in value
  );
}

export function mapAuthErrorToKey(error: AuthError): AuthErrorTranslationKey {
  const code = error.code ?? '';

  if (
    code === 'invalid_credentials' ||
    code === 'invalid_grant' ||
    code === 'invalid_login_credentials'
  ) {
    return 'auth.errors.invalidCredentials';
  }
  if (code === 'email_not_confirmed') {
    return 'auth.errors.emailNotConfirmed';
  }
  if (code === 'user_already_exists' || code === 'email_exists') {
    return 'auth.errors.alreadyRegistered';
  }
  if (code === 'weak_password') {
    return 'auth.errors.weakPassword';
  }
  if (
    code === 'over_email_send_rate_limit' ||
    code === 'over_request_rate_limit' ||
    error.status === 429
  ) {
    return 'auth.errors.rateLimited';
  }
  if (typeof error.status === 'number' && error.status >= 500) {
    return 'auth.errors.serviceUnavailable';
  }
  return 'auth.errors.generic';
}
