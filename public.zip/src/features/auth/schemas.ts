import { z } from 'zod';

export interface AuthValidationMessages {
  invalidEmail: string;
  passwordLength: string;
  passwordMismatch: string;
  nameLength: string;
}

const emailField = (message: string) => z.string().trim().pipe(z.email({ message }));

export function createSignInSchema(messages: AuthValidationMessages) {
  return z.object({
    email: emailField(messages.invalidEmail),
    password: z.string().min(8, messages.passwordLength).max(128, messages.passwordLength),
  });
}

export function createSignUpSchema(messages: AuthValidationMessages) {
  return z
    .object({
      displayName: z.string().trim().min(2, messages.nameLength).max(60, messages.nameLength),
      email: emailField(messages.invalidEmail),
      password: z.string().min(8, messages.passwordLength).max(128, messages.passwordLength),
      confirmPassword: z.string(),
    })
    .refine((values) => values.password === values.confirmPassword, {
      message: messages.passwordMismatch,
      path: ['confirmPassword'],
    });
}

export type SignInValues = z.infer<ReturnType<typeof createSignInSchema>>;
export type SignUpValues = z.infer<ReturnType<typeof createSignUpSchema>>;
