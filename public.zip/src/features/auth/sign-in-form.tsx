import { zodResolver } from '@hookform/resolvers/zod';
import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate } from 'react-router-dom';

import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

import { useAuth } from './auth-provider';
import { isAuthError, mapAuthErrorToKey, type AuthErrorTranslationKey } from './auth-errors';
import { PasswordInput } from './password-input';
import { getSafeRedirect } from './redirect';
import { createSignInSchema, type SignInValues } from './schemas';
import { useRevalidateOnLanguageChange } from './use-revalidate-on-language-change';

export function SignInForm() {
  const { t } = useTranslation();
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [serverError, setServerError] = useState<AuthErrorTranslationKey | null>(null);

  const schema = useMemo(
    () =>
      createSignInSchema({
        invalidEmail: t('auth.errors.invalidEmail'),
        passwordLength: t('auth.errors.passwordLength'),
        passwordMismatch: t('auth.errors.passwordMismatch'),
        nameLength: t('auth.errors.nameLength'),
      }),
    [t],
  );

  const {
    register,
    handleSubmit,
    trigger,
    formState: { errors, isSubmitting },
  } = useForm<SignInValues>({
    resolver: zodResolver(schema),
    mode: 'onTouched',
  });

  useRevalidateOnLanguageChange(errors, trigger);

  const onSubmit = async (values: SignInValues) => {
    setServerError(null);
    try {
      await signIn(values.email, values.password);
      navigate(getSafeRedirect(location.state), { replace: true });
    } catch (error) {
      setServerError(isAuthError(error) ? mapAuthErrorToKey(error) : 'auth.errors.generic');
    }
  };

  return (
    <div className="space-y-5">
      <header className="space-y-1.5">
        <h2 className="text-2xl font-bold text-fg">{t('auth.signInTitle')}</h2>
        <p className="text-sm leading-6 text-muted">{t('auth.signInSubtitle')}</p>
      </header>

      {serverError ? <Alert variant="error">{t(serverError)}</Alert> : null}

      <form
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="space-y-4"
        aria-busy={isSubmitting}
      >
        <Input
          label={t('auth.email')}
          type="email"
          autoComplete="email"
          inputMode="email"
          autoCapitalize="none"
          spellCheck={false}
          placeholder={t('auth.emailPlaceholder')}
          error={errors.email?.message}
          required
          {...register('email')}
        />
        <PasswordInput
          label={t('auth.password')}
          autoComplete="current-password"
          placeholder={t('auth.passwordPlaceholder')}
          error={errors.password?.message}
          required
          {...register('password')}
        />
        <Button
          type="submit"
          size="lg"
          className="w-full"
          isLoading={isSubmitting}
          loadingLabel={t('auth.signingIn')}
        >
          {t('auth.signInCta')}
        </Button>
      </form>
    </div>
  );
}
