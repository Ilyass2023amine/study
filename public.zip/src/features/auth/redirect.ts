export function getSafeRedirect(state: unknown): string {
  if (typeof state === 'object' && state !== null && 'from' in state) {
    const from: unknown = (state as { from?: unknown }).from;
    if (
      typeof from === 'string' &&
      from.startsWith('/') &&
      !from.startsWith('//') &&
      !from.startsWith('/auth')
    ) {
      return from;
    }
  }
  return '/account';
}
