import { useCallback, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

import { useToast } from '@/components/ui/toast';

import { useAuth } from './auth-provider';

export function useSignOut(): { signOut: () => Promise<void>; isPending: boolean } {
  const { signOut: revokeSession } = useAuth();
  const { toast } = useToast();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [isPending, setIsPending] = useState(false);

  const signOut = useCallback(async () => {
    setIsPending(true);
    try {
      navigate('/', { replace: true });
      await revokeSession();
      toast({
        variant: 'success',
        title: t('account.signOutSuccess'),
      });
    } catch {
      toast({
        variant: 'error',
        title: t('errors.unexpectedTitle'),
        description: t('auth.errors.generic'),
      });
    } finally {
      setIsPending(false);
    }
  }, [navigate, revokeSession, t, toast]);

  return { signOut, isPending };
}
