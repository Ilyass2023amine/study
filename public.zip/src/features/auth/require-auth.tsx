import { useTranslation } from 'react-i18next';
import { Navigate, Outlet, useLocation } from 'react-router-dom';

import { PageLoader } from '@/components/layout/page-loader';
import { ErrorState } from '@/components/ui/error-state';

import { useAuth } from './auth-provider';

export function RequireAuth() {
  const { status, isSigningOut } = useAuth();
  const { t } = useTranslation();
  const location = useLocation();

  if (status === 'loading' || (status === 'anonymous' && isSigningOut)) {
    return (
      <div className="min-h-dvh">
        <PageLoader />
      </div>
    );
  }

  if (status === 'unconfigured' || status === 'anonymous') {
    return (
      <Navigate to="/auth" state={{ from: `${location.pathname}${location.search}` }} replace />
    );
  }

  if (status === 'error') {
    return (
      <div className="container py-16">
        <ErrorState
          title={t('errors.unexpectedTitle')}
          description={t('auth.errors.generic')}
          retryLabel={t('common.retry')}
          onRetry={() => window.location.reload()}
        />
      </div>
    );
  }

  return <Outlet />;
}
