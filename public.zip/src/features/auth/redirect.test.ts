import { describe, expect, it } from 'vitest';

import { getSafeRedirect } from './redirect';

describe('getSafeRedirect', () => {
  it('returns the requested internal path', () => {
    expect(getSafeRedirect({ from: '/account?tab=preferences' })).toBe('/account?tab=preferences');
  });

  it('falls back to the account page for missing or invalid state', () => {
    expect(getSafeRedirect(undefined)).toBe('/account');
    expect(getSafeRedirect(null)).toBe('/account');
    expect(getSafeRedirect({ from: 42 })).toBe('/account');
  });

  it('rejects protocol-relative and external-style values', () => {
    expect(getSafeRedirect({ from: '//evil.example' })).toBe('/account');
    expect(getSafeRedirect({ from: 'https://evil.example' })).toBe('/account');
  });

  it('does not bounce back into the auth flow', () => {
    expect(getSafeRedirect({ from: '/auth?mode=signup' })).toBe('/account');
    expect(getSafeRedirect({ from: '/auth/callback' })).toBe('/account');
  });
});
