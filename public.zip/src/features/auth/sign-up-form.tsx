import { zodResolver } from '@hookform/resolvers/zod';
import { Mail } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate } from 'react-router-dom';

import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

import { useAuth } from './auth-provider';
import { isAuthError, mapAuthErrorToKey, type AuthErrorTranslationKey } from './auth-errors';
import { PasswordInput } from './password-input';
import { getSafeRedirect } from './redirect';
import { createSignUpSchema, type SignUpValues } from './schemas';
import { useRevalidateOnLanguageChange } from './use-revalidate-on-language-change';

export function SignUpForm({ onShowSignIn }: { onShowSignIn: () => void }) {
  const { t } = useTranslation();
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [serverError, setServerError] = useState<AuthErrorTranslationKey | null>(null);
  const [pendingEmail, setPendingEmail] = useState<string | null>(null);

  const schema = useMemo(
    () =>
      createSignUpSchema({
        invalidEmail: t('auth.errors.invalidEmail'),
        passwordLength: t('auth.errors.passwordLength'),
        passwordMismatch: t('auth.errors.passwordMismatch'),
        nameLength: t('auth.errors.nameLength'),
      }),
    [t],
  );

  const {
    register,
    handleSubmit,
    trigger,
    formState: { errors, isSubmitting },
  } = useForm<SignUpValues>({
    resolver: zodResolver(schema),
    mode: 'onTouched',
  });

  useRevalidateOnLanguageChange(errors, trigger);

  const onSubmit = async (values: SignUpValues) => {
    setServerError(null);
    try {
      const result = await signUp({
        email: values.email,
        password: values.password,
        displayName: values.displayName,
      });

      if (result.requiresEmailConfirmation) {
        setPendingEmail(values.email);
        return;
      }

      navigate(getSafeRedirect(location.state), { replace: true });
    } catch (error) {
      setServerError(isAuthError(error) ? mapAuthErrorToKey(error) : 'auth.errors.generic');
    }
  };

  if (pendingEmail) {
    return (
      <div className="flex flex-col items-center gap-3 py-4 text-center">
        <span className="bg-primary/12 flex size-14 items-center justify-center rounded-full text-link">
          <Mail className="size-7" aria-hidden="true" />
        </span>
        <h2 className="text-2xl font-bold text-fg">{t('auth.checkEmailTitle')}</h2>
        <p className="max-w-sm text-sm leading-6 text-muted">
          {t('auth.checkEmailBody', { email: pendingEmail })}
        </p>
        <p className="text-xs text-muted">{t('auth.checkEmailHint')}</p>
        <Button variant="secondary" className="mt-2" onClick={onShowSignIn}>
          {t('common.backToSignIn')}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <header className="space-y-1.5">
        <h2 className="text-2xl font-bold text-fg">{t('auth.signUpTitle')}</h2>
        <p className="text-sm leading-6 text-muted">{t('auth.signUpSubtitle')}</p>
      </header>

      {serverError ? <Alert variant="error">{t(serverError)}</Alert> : null}

      <form
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="space-y-4"
        aria-busy={isSubmitting}
      >
        <Input
          label={t('auth.displayName')}
          autoComplete="nickname"
          placeholder={t('auth.displayNamePlaceholder')}
          error={errors.displayName?.message}
          required
          {...register('displayName')}
        />
        <Input
          label={t('auth.email')}
          type="email"
          autoComplete="email"
          inputMode="email"
          autoCapitalize="none"
          spellCheck={false}
          placeholder={t('auth.emailPlaceholder')}
          error={errors.email?.message}
          required
          {...register('email')}
        />
        <PasswordInput
          label={t('auth.password')}
          autoComplete="new-password"
          placeholder={t('auth.passwordPlaceholder')}
          error={errors.password?.message}
          required
          {...register('password')}
        />
        <PasswordInput
          label={t('auth.confirmPassword')}
          autoComplete="new-password"
          error={errors.confirmPassword?.message}
          required
          {...register('confirmPassword')}
        />
        <Button
          type="submit"
          size="lg"
          className="w-full"
          isLoading={isSubmitting}
          loadingLabel={t('auth.signingUp')}
        >
          {t('auth.signUpCta')}
        </Button>
      </form>
    </div>
  );
}
