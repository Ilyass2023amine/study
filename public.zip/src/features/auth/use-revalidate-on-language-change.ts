import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import type { FieldErrors, FieldValues, UseFormTrigger } from 'react-hook-form';

export function useRevalidateOnLanguageChange<T extends FieldValues>(
  errors: FieldErrors<T>,
  trigger: UseFormTrigger<T>,
): void {
  const { i18n } = useTranslation();
  const hasErrors = Object.keys(errors).length > 0;

  useEffect(() => {
    if (hasErrors) {
      void trigger();
    }
  }, [hasErrors, i18n.language, trigger]);
}
