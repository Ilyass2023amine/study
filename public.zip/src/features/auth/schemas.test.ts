import { describe, expect, it } from 'vitest';

import { createSignInSchema, createSignUpSchema } from './schemas';

const messages = {
  invalidEmail: 'Invalid email.',
  passwordLength: 'Password must have at least 8 characters.',
  passwordMismatch: 'Passwords do not match.',
  nameLength: 'Name must have between 2 and 60 characters.',
};

describe('auth schemas', () => {
  it('accepts a valid sign-in payload and trims the email', () => {
    const result = createSignInSchema(messages).safeParse({
      email: '  sara@example.com ',
      password: 'correct-horse',
    });

    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.email).toBe('sara@example.com');
    }
  });

  it('rejects an invalid email and short password', () => {
    const result = createSignInSchema(messages).safeParse({
      email: 'not-an-email',
      password: 'short',
    });

    expect(result.success).toBe(false);
    if (!result.success) {
      const paths = result.error.issues.map((issue) => issue.path.join('.'));
      expect(paths).toContain('email');
      expect(paths).toContain('password');
    }
  });

  it('rejects mismatched passwords on sign-up', () => {
    const result = createSignUpSchema(messages).safeParse({
      displayName: 'Sara',
      email: 'sara@example.com',
      password: 'correct-horse',
      confirmPassword: 'battery-staple',
    });

    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues[0]?.path).toEqual(['confirmPassword']);
      expect(result.error.issues[0]?.message).toBe(messages.passwordMismatch);
    }
  });

  it('rejects a too-short display name', () => {
    const result = createSignUpSchema(messages).safeParse({
      displayName: 'S',
      email: 'sara@example.com',
      password: 'correct-horse',
      confirmPassword: 'correct-horse',
    });

    expect(result.success).toBe(false);
  });
});
