import type { Session, User } from '@supabase/supabase-js';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

import { requireSupabase, supabase } from '@/lib/supabase';

export type AuthStatus = 'loading' | 'unconfigured' | 'authenticated' | 'anonymous' | 'error';

interface SignUpInput {
  email: string;
  password: string;
  displayName: string;
}

interface AuthContextValue {
  status: AuthStatus;
  session: Session | null;
  user: User | null;
  initializationError: string | null;
  isSigningOut: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (input: SignUpInput) => Promise<{ requiresEmailConfirmation: boolean }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const client = supabase;
  const [status, setStatus] = useState<AuthStatus>(() => (client ? 'loading' : 'unconfigured'));
  const [session, setSession] = useState<Session | null>(null);
  const [initializationError, setInitializationError] = useState<string | null>(null);
  const [isSigningOut, setIsSigningOut] = useState(false);

  useEffect(() => {
    if (!client) return;

    let isMounted = true;

    const initialize = async () => {
      const { data, error } = await client.auth.getSession();
      if (!isMounted) return;

      if (error) {
        setInitializationError(error.message);
        setStatus('error');
        return;
      }

      setSession(data.session);
      setStatus(data.session ? 'authenticated' : 'anonymous');
    };

    void initialize();

    const { data: subscription } = client.auth.onAuthStateChange((_event, nextSession) => {
      if (!isMounted) return;
      setSession(nextSession);
      setStatus(nextSession ? 'authenticated' : 'anonymous');
    });

    return () => {
      isMounted = false;
      subscription.subscription.unsubscribe();
    };
  }, [client]);

  const signIn = useCallback(async (email: string, password: string) => {
    const auth = requireSupabase().auth;
    const { data, error } = await auth.signInWithPassword({ email, password });
    if (error) throw error;
    setSession(data.session);
    setStatus('authenticated');
  }, []);

  const signUp = useCallback(async ({ email, password, displayName }: SignUpInput) => {
    const auth = requireSupabase().auth;
    const { data, error } = await auth.signUp({
      email,
      password,
      options: {
        data: {
          display_name: displayName,
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;

    if (data.session) {
      setSession(data.session);
      setStatus('authenticated');
      return { requiresEmailConfirmation: false };
    }

    return { requiresEmailConfirmation: true };
  }, []);

  const signOut = useCallback(async () => {
    setIsSigningOut(true);
    try {
      const { error } = await requireSupabase().auth.signOut();
      if (error) throw error;
      setSession(null);
      setStatus('anonymous');
    } finally {
      setIsSigningOut(false);
    }
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      status,
      session,
      user: session?.user ?? null,
      initializationError,
      isSigningOut,
      signIn,
      signUp,
      signOut,
    }),
    [initializationError, isSigningOut, session, signIn, signOut, signUp, status],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
