import { useQuery } from '@tanstack/react-query';

import { requireSupabase } from '@/lib/supabase';

export function useProfile(userId: string | null) {
  return useQuery({
    queryKey: ['profile', userId],
    enabled: userId !== null,
    queryFn: async () => {
      if (!userId) {
        throw new Error('A signed-in user is required to load a profile.');
      }

      const { data, error } = await requireSupabase()
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
  });
}
