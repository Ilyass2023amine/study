import { ChevronDown, Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';

import type { AppLanguage } from '@/lib/i18n';
import { cn } from '@/lib/utils';

import { useLanguage } from './use-language';

const OPTIONS: { value: AppLanguage; labelKey: 'language.fr' | 'language.ar' | 'language.dar' }[] =
  [
    { value: 'fr', labelKey: 'language.fr' },
    { value: 'ar', labelKey: 'language.ar' },
    { value: 'dar', labelKey: 'language.dar' },
  ];

export function LanguageSwitcher({ className }: { className?: string }) {
  const { t } = useTranslation();
  const { language, changeLanguage } = useLanguage();

  return (
    <div className={cn('relative inline-flex items-center', className)}>
      <Globe
        className="pointer-events-none absolute start-3 size-4 text-muted"
        aria-hidden="true"
      />
      <select
        aria-label={t('language.label')}
        value={language}
        onChange={(event) => {
          const value = event.target.value;
          const match = OPTIONS.find((option) => option.value === value);
          if (match) {
            void changeLanguage(match.value);
          }
        }}
        className="min-h-11 cursor-pointer appearance-none rounded-full border border-line bg-surface/80 pe-8 ps-9 text-sm font-semibold text-fg transition-colors hover:border-fg/25 focus:border-ring focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-canvas"
      >
        {OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {t(option.labelKey)}
          </option>
        ))}
      </select>
      <ChevronDown
        className="pointer-events-none absolute end-3 size-4 text-muted"
        aria-hidden="true"
      />
    </div>
  );
}
