import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';

import { LANGUAGE_STORAGE_KEY } from '@/lib/constants';
import { applyDocumentLanguage, isAppLanguage, type AppLanguage } from '@/lib/i18n';
import { writeStorage } from '@/lib/storage';

export function useLanguage(): {
  language: AppLanguage;
  changeLanguage: (language: AppLanguage) => Promise<void>;
} {
  const { i18n } = useTranslation();
  const resolved = i18n.resolvedLanguage;
  const language = isAppLanguage(resolved) ? resolved : 'fr';

  const changeLanguage = useCallback(
    async (next: AppLanguage) => {
      await i18n.changeLanguage(next);
      applyDocumentLanguage(next);
      writeStorage(LANGUAGE_STORAGE_KEY, next);
    },
    [i18n],
  );

  return { language, changeLanguage };
}
