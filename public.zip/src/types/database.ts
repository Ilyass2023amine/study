export type UserRole = 'student' | 'parent' | 'teacher' | 'admin';
export type AppLanguageCode = 'fr' | 'ar' | 'dar';

export type Profile = {
  id: string;
  role: UserRole;
  display_name: string;
  preferred_language: AppLanguageCode;
  onboarded_at: string | null;
  created_at: string;
  updated_at: string;
};

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: {
          id: string;
          role?: UserRole;
          display_name: string;
          preferred_language?: AppLanguageCode;
          onboarded_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          role?: UserRole;
          display_name?: string;
          preferred_language?: AppLanguageCode;
          onboarded_at?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: { [_ in never]: never };
    Enums: {
      user_role: UserRole;
      app_language: AppLanguageCode;
    };
    CompositeTypes: { [_ in never]: never };
  };
}
