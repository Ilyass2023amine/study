import type { AppLanguage } from './i18n';

export function formatLongDate(value: string, language: AppLanguage): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  const locale = language === 'fr' ? 'fr-MA' : 'ar-MA';
  return new Intl.DateTimeFormat(locale, {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(date);
}
