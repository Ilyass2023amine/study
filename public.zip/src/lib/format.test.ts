import { describe, expect, it } from 'vitest';

import { formatLongDate } from './format';

describe('formatLongDate', () => {
  it('formats an ISO timestamp for the active language', () => {
    const french = formatLongDate('2026-11-02T10:30:00.000Z', 'fr');
    const arabic = formatLongDate('2026-11-02T10:30:00.000Z', 'ar');

    expect(french).not.toBe('—');
    expect(arabic).not.toBe('—');
    expect(french).toMatch(/2026/);
  });

  it('returns a fallback for invalid input', () => {
    expect(formatLongDate('not-a-date', 'fr')).toBe('—');
  });
});
