import { z } from 'zod';

const envSchema = z
  .object({
    VITE_SUPABASE_URL: z.url({ message: 'VITE_SUPABASE_URL must be a valid URL.' }).optional(),
    VITE_SUPABASE_ANON_KEY: z
      .string()
      .trim()
      .min(20, 'VITE_SUPABASE_ANON_KEY is too short to be a valid anon/publishable key.')
      .optional(),
  })
  .superRefine((value, context) => {
    if (Boolean(value.VITE_SUPABASE_URL) !== Boolean(value.VITE_SUPABASE_ANON_KEY)) {
      context.addIssue({
        code: 'custom',
        message:
          'VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY must both be set, or both be omitted.',
      });
    }
  });

const rawEnv: Record<string, unknown> = {
  VITE_SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL,
  VITE_SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY,
};

const parsed = envSchema.safeParse(rawEnv);

export const env = parsed.success ? parsed.data : {};

export const configurationError: string | null = parsed.success
  ? null
  : parsed.error.issues.map((issue) => issue.message).join(' ');

export const isSupabaseConfigured = Boolean(
  parsed.success && env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY,
);
