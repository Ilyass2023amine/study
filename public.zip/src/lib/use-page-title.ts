import { useEffect } from 'react';

const BRAND = 'StudyVerse';

export function usePageTitle(title?: string): void {
  useEffect(() => {
    document.title = title ? `${title} · ${BRAND}` : BRAND;
  }, [title]);
}
