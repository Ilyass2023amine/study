import { describe, expect, it } from 'vitest';

import { ar } from './ar';
import { dar } from './dar';
import { fr } from './fr';

type LocaleCopy = typeof fr;

function flatten(value: object, prefix = ''): Map<string, string> {
  const entries = new Map<string, string>();

  for (const [key, child] of Object.entries(value)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (typeof child === 'string') {
      entries.set(path, child);
    } else if (child && typeof child === 'object') {
      for (const [nestedKey, nestedValue] of flatten(child, path)) {
        entries.set(nestedKey, nestedValue);
      }
    }
  }

  return entries;
}

function placeholders(value: string): string[] {
  return [...value.matchAll(/{{\s*(\w+)\s*}}/g)].map((match) => match[1] ?? '').sort();
}

const locales: { name: string; copy: LocaleCopy }[] = [
  { name: 'ar', copy: ar },
  { name: 'dar', copy: dar },
];

const frenchKeys = [...flatten(fr).keys()].sort();
const frenchCopy = flatten(fr);

describe('translation catalogues', () => {
  it.each(locales)('$name has exactly the French key set', ({ copy }) => {
    expect([...flatten(copy).keys()].sort()).toEqual(frenchKeys);
  });

  it.each(locales)('$name has no blank strings and keeps interpolation tokens', ({ copy }) => {
    for (const [key, value] of flatten(copy)) {
      expect(value.trim(), `${key} is blank`).not.toBe('');
      expect(placeholders(value), `${key} placeholders differ from French`).toEqual(
        placeholders(frenchCopy.get(key) ?? ''),
      );
    }
  });
});
