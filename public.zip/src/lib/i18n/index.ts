import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import { LANGUAGE_STORAGE_KEY } from '@/lib/constants';
import { readStorage } from '@/lib/storage';

import { ar } from './translations/ar';
import { dar } from './translations/dar';
import { fr } from './translations/fr';

export const SUPPORTED_LANGUAGES = ['fr', 'ar', 'dar'] as const;
export type AppLanguage = (typeof SUPPORTED_LANGUAGES)[number];

export function isAppLanguage(value: unknown): value is AppLanguage {
  return typeof value === 'string' && SUPPORTED_LANGUAGES.some((language) => language === value);
}

export function applyDocumentLanguage(language: AppLanguage): void {
  if (typeof document === 'undefined') return;
  document.documentElement.lang = language === 'dar' ? 'ary' : language;
  document.documentElement.dir = language === 'fr' ? 'ltr' : 'rtl';
}

function getInitialLanguage(): AppLanguage {
  const stored = readStorage(LANGUAGE_STORAGE_KEY);
  return isAppLanguage(stored) ? stored : 'fr';
}

export const resources = {
  fr: { translation: fr },
  ar: { translation: ar },
  dar: { translation: dar },
};

const initialLanguage = getInitialLanguage();

void i18n.use(initReactI18next).init({
  resources,
  lng: initialLanguage,
  fallbackLng: 'fr',
  supportedLngs: [...SUPPORTED_LANGUAGES],
  defaultNS: 'translation',
  interpolation: {
    escapeValue: false,
  },
  returnNull: false,
  react: {
    useSuspense: false,
  },
});

applyDocumentLanguage(initialLanguage);

export default i18n;

declare module 'i18next' {
  interface CustomTypeOptions {
    defaultNS: 'translation';
    resources: {
      translation: typeof fr;
    };
  }
}
