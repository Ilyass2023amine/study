export const LANGUAGE_STORAGE_KEY = 'studyverse.language';
export const THEME_STORAGE_KEY = 'studyverse.theme';
