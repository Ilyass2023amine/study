import { Compass } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

import { buttonVariants } from '@/components/ui/button';
import { EmptyState } from '@/components/ui/empty-state';
import { usePageTitle } from '@/lib/use-page-title';

export default function NotFoundPage() {
  const { t } = useTranslation();
  usePageTitle(t('notFound.title'));

  return (
    <div className="container flex min-h-[70dvh] items-center justify-center py-16">
      <div className="w-full max-w-lg">
        <p
          aria-hidden="true"
          className="mb-4 text-center font-display text-6xl font-extrabold text-primary/35"
        >
          404
        </p>
        <EmptyState
          icon={Compass}
          title={t('notFound.title')}
          description={t('notFound.subtitle')}
          action={
            <Link to="/" className={buttonVariants()}>
              {t('notFound.action')}
            </Link>
          }
        />
      </div>
    </div>
  );
}
