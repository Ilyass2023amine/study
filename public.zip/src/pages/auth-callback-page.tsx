import { AlertCircle, LogIn } from 'lucide-react';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, Navigate } from 'react-router-dom';

import { BrandMark } from '@/components/brand/brand-mark';
import { Alert } from '@/components/ui/alert';
import { buttonVariants } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { useAuth } from '@/features/auth/auth-provider';
import { usePageTitle } from '@/lib/use-page-title';
import { cn } from '@/lib/utils';

function readCallbackError(): string | null {
  if (typeof window === 'undefined') return null;
  const search = new URLSearchParams(window.location.search);
  const hash = new URLSearchParams(window.location.hash.replace(/^#/, ''));
  return (
    search.get('error_description') ??
    hash.get('error_description') ??
    search.get('error') ??
    hash.get('error')
  );
}

export default function AuthCallbackPage() {
  const { t } = useTranslation();
  const { status } = useAuth();
  const callbackError = useMemo(() => readCallbackError(), []);

  usePageTitle(t('authCallback.workingTitle'));

  if (status === 'authenticated') {
    return <Navigate to="/account" replace />;
  }

  const isLoading = status === 'loading';
  const isUnconfigured = status === 'unconfigured';
  const hasError = Boolean(callbackError) || status === 'anonymous' || status === 'error';

  return (
    <main
      id="main-content"
      className="flex min-h-dvh flex-col items-center justify-center gap-6 px-4 py-12"
    >
      <BrandMark size={56} />
      <Card className="w-full max-w-md p-6 text-center sm:p-8">
        {isLoading ? (
          <div role="status" className="flex flex-col items-center gap-4">
            <Spinner size="lg" />
            <div className="space-y-1.5">
              <h1 className="text-xl font-bold text-fg">{t('authCallback.workingTitle')}</h1>
              <p className="text-sm text-muted">{t('authCallback.workingText')}</p>
            </div>
          </div>
        ) : hasError || isUnconfigured ? (
          <div className="flex flex-col items-center gap-4">
            <span className="bg-danger/12 flex size-14 items-center justify-center rounded-full text-danger">
              <AlertCircle className="size-7" aria-hidden="true" />
            </span>
            <div className="space-y-1.5">
              <h1 className="text-xl font-bold text-fg">
                {isUnconfigured
                  ? t('auth.configTitle')
                  : callbackError
                    ? t('authCallback.errorTitle')
                    : t('authCallback.missingTitle')}
              </h1>
              <p className="text-sm leading-6 text-muted">
                {isUnconfigured
                  ? t('auth.configBody')
                  : callbackError
                    ? t('authCallback.errorFallback')
                    : t('authCallback.missingBody')}
              </p>
            </div>
            {isUnconfigured ? (
              <Alert variant="warning" className="w-full text-start">
                {t('auth.configDocs')}
              </Alert>
            ) : null}
            <div className="mt-2 flex flex-col gap-2 sm:flex-row">
              <Link to="/auth" className={cn(buttonVariants(), 'w-full sm:w-auto')}>
                <LogIn className="size-4" aria-hidden="true" />
                {t('authCallback.backToAuth')}
              </Link>
              <Link to="/" className={cn(buttonVariants({ variant: 'ghost' }), 'w-full sm:w-auto')}>
                {t('common.backHome')}
              </Link>
            </div>
          </div>
        ) : null}
      </Card>
    </main>
  );
}
