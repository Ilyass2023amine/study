import {
  ArrowRight,
  BookOpen,
  CalendarDays,
  Check,
  ListChecks,
  ShieldCheck,
  Sparkles,
  type LucideIcon,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

import { Badge } from '@/components/ui/badge';
import { buttonVariants } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { usePageTitle } from '@/lib/use-page-title';
import { cn } from '@/lib/utils';

const FEATURES: {
  icon: LucideIcon;
  titleKey:
    'landing.features.tutorTitle' | 'landing.features.quizTitle' | 'landing.features.plannerTitle';
  textKey:
    'landing.features.tutorText' | 'landing.features.quizText' | 'landing.features.plannerText';
  tone: 'primary' | 'accent' | 'success';
}[] = [
  {
    icon: Sparkles,
    titleKey: 'landing.features.tutorTitle',
    textKey: 'landing.features.tutorText',
    tone: 'primary',
  },
  {
    icon: ListChecks,
    titleKey: 'landing.features.quizTitle',
    textKey: 'landing.features.quizText',
    tone: 'accent',
  },
  {
    icon: CalendarDays,
    titleKey: 'landing.features.plannerTitle',
    textKey: 'landing.features.plannerText',
    tone: 'success',
  },
];

const STEPS = [
  { titleKey: 'landing.how.step1Title', textKey: 'landing.how.step1Text' },
  { titleKey: 'landing.how.step2Title', textKey: 'landing.how.step2Text' },
  { titleKey: 'landing.how.step3Title', textKey: 'landing.how.step3Text' },
] as const;

const TONE_CLASSES = {
  primary: 'bg-primary/12 text-link',
  accent: 'bg-accent/12 text-accent',
  success: 'bg-success/10 text-success',
};

function HeroPanel() {
  const { t } = useTranslation();

  const rows = [
    {
      icon: Sparkles,
      title: t('landing.heroPanel.tutor'),
      description: t('landing.heroPanel.tutorDesc'),
      tone: 'primary' as const,
    },
    {
      icon: ListChecks,
      title: t('landing.heroPanel.quiz'),
      description: t('landing.heroPanel.quizDesc'),
      tone: 'accent' as const,
    },
    {
      icon: CalendarDays,
      title: t('landing.heroPanel.planner'),
      description: t('landing.heroPanel.plannerDesc'),
      tone: 'success' as const,
    },
  ];

  return (
    <div className="relative mx-auto w-full max-w-lg">
      <div
        aria-hidden="true"
        className="absolute -inset-6 rounded-[2.5rem] bg-gradient-to-br from-primary/25 via-transparent to-accent/20 blur-2xl"
      />
      <div className="glass relative rounded-panel p-5 shadow-2xl sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-brand-gradient text-white shadow-glow">
              <BookOpen className="size-4" aria-hidden="true" />
            </span>
            <h2 className="truncate text-sm font-semibold text-fg">
              {t('landing.heroPanel.title')}
            </h2>
          </div>
          <Badge variant="success">{t('landing.heroPanel.status')}</Badge>
        </div>

        <ul className="mt-5 space-y-2.5">
          {rows.map(({ icon: Icon, title, description, tone }) => (
            <li
              key={title}
              className="flex items-start gap-3 rounded-2xl border border-line/70 bg-canvas/45 p-3.5"
            >
              <span
                className={cn(
                  'flex size-9 shrink-0 items-center justify-center rounded-xl',
                  TONE_CLASSES[tone],
                )}
              >
                <Icon className="size-4" aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-fg">{title}</p>
                <p className="mt-0.5 text-xs leading-5 text-muted">{description}</p>
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-line/60 pt-4">
          <span className="text-xs font-medium text-muted">{t('landing.heroPanel.footnote')}</span>
          <span className="text-[11px] text-muted/80">{t('landing.previewNotice')}</span>
        </div>
      </div>
      <span
        aria-hidden="true"
        className="absolute -end-3 -top-5 flex size-11 animate-float items-center justify-center rounded-2xl border border-line bg-surface text-accent shadow-glow-cyan"
      >
        <Sparkles className="size-5" />
      </span>
    </div>
  );
}

export default function LandingPage() {
  const { t } = useTranslation();
  usePageTitle(t('app.tagline'));

  return (
    <>
      <section className="relative overflow-hidden border-b border-line/40">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-hero-radial" />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-grid-faint opacity-[0.22] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)]"
        />
        <div
          aria-hidden="true"
          className="aurora start-[8%] top-10 size-64 animate-soft-pulse bg-primary/30"
        />
        <div
          aria-hidden="true"
          className="aurora end-[5%] top-40 size-72 animate-soft-pulse bg-accent/15 [animation-delay:-4s]"
        />

        <div className="container relative grid gap-14 py-16 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-12 lg:py-24">
          <div className="max-w-2xl">
            <div className="animate-fade-up">
              <Badge variant="accent" className="border-accent/30 bg-accent/10">
                <Sparkles className="size-3.5" aria-hidden="true" />
                {t('landing.eyebrow')}
              </Badge>
            </div>
            <h1 className="mt-5 animate-fade-up text-display-md [animation-delay:60ms] lg:text-display-lg">
              {t('landing.titleBefore')}{' '}
              <span className="text-gradient">{t('landing.titleAccent')}</span>
            </h1>
            <p className="mt-6 max-w-xl animate-fade-up text-base leading-7 text-muted [animation-delay:120ms] sm:text-lg sm:leading-8">
              {t('landing.subtitle')}
            </p>

            <div className="mt-8 flex animate-fade-up flex-col gap-3 [animation-delay:180ms] sm:flex-row">
              <Link
                to="/auth?mode=signup"
                className={cn(buttonVariants({ size: 'lg' }), 'w-full sm:w-auto')}
              >
                {t('landing.primaryCta')}
                <ArrowRight className="size-4 rtl:rotate-180" aria-hidden="true" />
              </Link>
              <Link
                to="/auth"
                className={cn(
                  buttonVariants({ variant: 'secondary', size: 'lg' }),
                  'w-full sm:w-auto',
                )}
              >
                {t('landing.secondaryCta')}
              </Link>
            </div>

            <ul className="mt-8 flex animate-fade-up flex-wrap gap-x-5 gap-y-2 text-sm text-muted [animation-delay:240ms]">
              {[
                t('landing.trustPoints.data'),
                t('landing.trustPoints.noAds'),
                t('landing.trustPoints.guardian'),
              ].map((point) => (
                <li key={point} className="flex items-center gap-1.5">
                  <Check className="size-4 text-success" aria-hidden="true" />
                  {point}
                </li>
              ))}
            </ul>
          </div>

          <div className="animate-fade-up [animation-delay:200ms]">
            <HeroPanel />
          </div>
        </div>
      </section>

      <section id="features" className="container scroll-mt-24 py-20 sm:py-24">
        <div className="max-w-2xl">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-link">
            {t('landing.features.eyebrow')}
          </p>
          <h2 className="mt-3 text-display-sm">{t('landing.features.title')}</h2>
        </div>

        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {FEATURES.map(({ icon: Icon, titleKey, textKey, tone }) => (
            <Card key={titleKey} className="flex flex-col gap-4 p-6">
              <span
                className={cn(
                  'flex size-12 items-center justify-center rounded-2xl',
                  TONE_CLASSES[tone],
                )}
              >
                <Icon className="size-6" aria-hidden="true" />
              </span>
              <div className="space-y-2">
                <h3 className="text-lg font-bold text-fg">{t(titleKey)}</h3>
                <p className="text-sm leading-6 text-muted">{t(textKey)}</p>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section id="how" className="scroll-mt-24 border-y border-line/60 bg-surface/25">
        <div className="container py-20 sm:py-24">
          <div className="max-w-2xl">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-link">
              {t('landing.how.eyebrow')}
            </p>
            <h2 className="mt-3 text-display-sm">{t('landing.how.title')}</h2>
          </div>

          <ol className="mt-10 grid gap-5 md:grid-cols-3">
            {STEPS.map((step, index) => (
              <li key={step.titleKey} className="relative">
                <Card className="h-full p-6">
                  <span
                    aria-hidden="true"
                    className="font-display text-3xl font-extrabold text-primary/35"
                  >
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <h3 className="mt-4 text-lg font-bold text-fg">{t(step.titleKey)}</h3>
                  <p className="mt-2 text-sm leading-6 text-muted">{t(step.textKey)}</p>
                </Card>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section id="safety" className="container scroll-mt-24 py-20 sm:py-24">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center lg:gap-16">
          <div className="relative overflow-hidden rounded-panel border border-primary/20 bg-gradient-to-br from-primary/15 via-surface/50 to-accent/10 p-8 sm:p-10">
            <div
              aria-hidden="true"
              className="absolute -end-12 -top-12 size-48 rounded-full bg-primary/20 blur-3xl"
            />
            <span className="flex size-16 items-center justify-center rounded-2xl border border-primary/25 bg-primary/15 text-link shadow-glow">
              <ShieldCheck className="size-8" aria-hidden="true" />
            </span>
            <p className="mt-6 max-w-md font-display text-xl font-bold leading-8 text-fg">
              {t('landing.safety.text')}
            </p>
            <ul className="mt-6 space-y-2.5">
              {[
                t('landing.trustPoints.data'),
                t('landing.trustPoints.noAds'),
                t('landing.trustPoints.guardian'),
              ].map((point) => (
                <li key={point} className="flex items-center gap-2 text-sm text-muted">
                  <Check className="size-4 shrink-0 text-success" aria-hidden="true" />
                  {point}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-link">
              {t('landing.safety.eyebrow')}
            </p>
            <h2 className="mt-3 text-display-sm">{t('landing.safety.title')}</h2>
            <ul className="mt-7 space-y-4">
              {[
                t('landing.safety.bullets.consent'),
                t('landing.safety.bullets.privacy'),
                t('landing.safety.bullets.control'),
              ].map((point) => (
                <li key={point} className="flex items-start gap-3 text-sm leading-6 text-muted">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-success/15 text-success">
                    <Check className="size-3" aria-hidden="true" />
                  </span>
                  {point}
                </li>
              ))}
            </ul>
            <Link
              to="/privacy"
              className="mt-7 inline-flex min-h-11 items-center gap-2 rounded-full text-sm font-semibold text-link hover:text-fg"
            >
              {t('landing.safety.privacyLink')}
              <ArrowRight className="size-4 rtl:rotate-180" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      <section className="container pb-20 sm:pb-24">
        <div className="relative overflow-hidden rounded-panel border border-primary/25 bg-primary/10 px-6 py-12 text-center sm:px-12 sm:py-16">
          <div
            aria-hidden="true"
            className="absolute start-1/2 top-0 size-72 -translate-x-1/2 rounded-full bg-primary/25 blur-3xl rtl:translate-x-1/2"
          />
          <div className="relative">
            <h2 className="mx-auto max-w-2xl text-display-sm">{t('landing.finalCta.title')}</h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-muted sm:text-base">
              {t('landing.finalCta.subtitle')}
            </p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Link
                to="/auth?mode=signup"
                className={cn(buttonVariants({ size: 'lg' }), 'w-full sm:w-auto')}
              >
                {t('landing.primaryCta')}
                <ArrowRight className="size-4 rtl:rotate-180" aria-hidden="true" />
              </Link>
              <Link
                to="/auth"
                className={cn(
                  buttonVariants({ variant: 'secondary', size: 'lg' }),
                  'w-full sm:w-auto',
                )}
              >
                {t('landing.secondaryCta')}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
