import { useQueryClient } from '@tanstack/react-query';
import {
  BadgeCheck,
  CalendarDays,
  Languages,
  LogOut,
  Mail,
  Moon,
  ShieldCheck,
  Sun,
  UserRound,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';

import { PageLoader } from '@/components/layout/page-loader';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { EmptyState } from '@/components/ui/empty-state';
import { ErrorState } from '@/components/ui/error-state';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/features/auth/auth-provider';
import { getUserDisplayName } from '@/features/auth/user';
import { useSignOut } from '@/features/auth/use-sign-out';
import { useLanguage } from '@/features/preferences/use-language';
import { useTheme } from '@/features/preferences/theme-provider';
import { LanguageSwitcher } from '@/features/preferences/language-switcher';
import { useProfile } from '@/features/profile/use-profile';
import { formatLongDate } from '@/lib/format';
import { usePageTitle } from '@/lib/use-page-title';
import type { UserRole } from '@/types/database';

const ROLE_LABEL_KEYS = {
  student: 'account.roleLabels.student',
  parent: 'account.roleLabels.parent',
  teacher: 'account.roleLabels.teacher',
  admin: 'account.roleLabels.admin',
} as const satisfies Record<UserRole, string>;

function ProfileSkeleton() {
  const { t } = useTranslation();

  return (
    <div role="status" aria-busy="true" aria-live="polite" className="space-y-6">
      <span className="sr-only">{t('account.loadingLabel')}</span>
      <div className="flex items-center gap-4">
        <Skeleton className="size-20 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-5 w-24 rounded-full" />
        </div>
      </div>
      <div className="space-y-4 border-t border-line/70 pt-5">
        <Skeleton className="h-11 w-full" />
        <Skeleton className="h-11 w-full" />
        <Skeleton className="h-11 w-full" />
      </div>
    </div>
  );
}

export default function AccountPage() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { language } = useLanguage();
  const { theme, setTheme } = useTheme();
  const { signOut, isPending } = useSignOut();
  const profileQuery = useProfile(user?.id ?? null);
  const queryClient = useQueryClient();
  const profile = profileQuery.data ?? null;
  const displayName = profile?.display_name ?? getUserDisplayName(user);

  usePageTitle(t('account.eyebrow'));

  if (!user) {
    return (
      <div className="min-h-dvh">
        <PageLoader />
      </div>
    );
  }

  const retryProfile = () => {
    void queryClient.invalidateQueries({ queryKey: ['profile', user.id] });
  };

  const isOnboarded = Boolean(profile?.onboarded_at);

  return (
    <section className="mx-auto max-w-5xl">
      <Badge variant="primary">
        <UserRound className="size-3.5" aria-hidden="true" />
        {t('account.eyebrow')}
      </Badge>
      <h1 className="mt-4 text-display-sm">{t('account.greeting', { name: displayName })}</h1>
      <p className="mt-3 max-w-2xl text-sm leading-6 text-muted sm:text-base">
        {t('account.subtitle')}
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('account.profileTitle')}</CardTitle>
              <CardDescription>{t('account.profileHint')}</CardDescription>
            </CardHeader>
            <CardContent>
              {profileQuery.isPending ? (
                <ProfileSkeleton />
              ) : profileQuery.isError ? (
                <ErrorState
                  title={t('account.loadErrorTitle')}
                  description={t('account.loadErrorBody')}
                  retryLabel={t('account.retry')}
                  onRetry={retryProfile}
                />
              ) : !profile ? (
                <EmptyState
                  icon={UserRound}
                  title={t('account.missingTitle')}
                  description={t('account.missingBody')}
                  action={
                    <Button variant="secondary" size="sm" onClick={retryProfile}>
                      {t('account.retry')}
                    </Button>
                  }
                />
              ) : (
                <div className="space-y-6">
                  <div className="flex flex-wrap items-center gap-4">
                    <Avatar name={displayName} size="xl" />
                    <div className="min-w-0">
                      <h2 className="break-words text-xl font-bold text-fg">{displayName}</h2>
                      <Badge variant="primary" className="mt-2">
                        {t(ROLE_LABEL_KEYS[profile.role])}
                      </Badge>
                    </div>
                  </div>

                  <dl className="space-y-4 border-t border-line/70 pt-5">
                    <div className="flex items-start gap-3">
                      <Mail className="mt-0.5 size-4 shrink-0 text-muted" aria-hidden="true" />
                      <div className="min-w-0">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-muted">
                          {t('account.email')}
                        </dt>
                        <dd className="break-all text-sm font-medium text-fg">
                          {user.email ?? '—'}
                        </dd>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <ShieldCheck
                        className="mt-0.5 size-4 shrink-0 text-muted"
                        aria-hidden="true"
                      />
                      <div className="min-w-0">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-muted">
                          {t('account.role')}
                        </dt>
                        <dd className="text-sm font-medium text-fg">
                          {t(ROLE_LABEL_KEYS[profile.role])}
                        </dd>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CalendarDays
                        className="mt-0.5 size-4 shrink-0 text-muted"
                        aria-hidden="true"
                      />
                      <div className="min-w-0">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-muted">
                          {t('account.memberSince')}
                        </dt>
                        <dd className="text-sm font-medium text-fg">
                          {formatLongDate(profile.created_at, language)}
                        </dd>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <BadgeCheck
                        className="mt-0.5 size-4 shrink-0 text-muted"
                        aria-hidden="true"
                      />
                      <div className="min-w-0">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-muted">
                          {t('account.status')}
                        </dt>
                        <dd className="mt-1">
                          <Badge variant={isOnboarded ? 'success' : 'warning'}>
                            {t(isOnboarded ? 'account.onboarded' : 'account.notOnboarded')}
                          </Badge>
                        </dd>
                      </div>
                    </div>
                  </dl>
                </div>
              )}
            </CardContent>
          </Card>

          {profile && !isOnboarded ? (
            <Card variant="subtle" className="flex items-start gap-3 p-5">
              <span className="bg-primary/12 flex size-10 shrink-0 items-center justify-center rounded-xl text-link">
                <BadgeCheck className="size-5" aria-hidden="true" />
              </span>
              <div>
                <h2 className="text-sm font-bold text-fg">{t('account.nextStep')}</h2>
                <p className="mt-1 text-sm leading-6 text-muted">{t('account.onboardingSoon')}</p>
              </div>
            </Card>
          ) : null}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('account.preferencesTitle')}</CardTitle>
              <CardDescription>{t('account.preferencesText')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-2">
                <p className="flex items-center gap-2 text-sm font-semibold text-fg">
                  <Languages className="size-4 text-muted" aria-hidden="true" />
                  {t('account.languageLabel')}
                </p>
                <LanguageSwitcher className="w-full [&_select]:w-full" />
              </div>

              <div className="space-y-2">
                <p className="text-sm font-semibold text-fg">{t('account.themeLabel')}</p>
                <div role="group" aria-label={t('theme.label')} className="flex items-center gap-2">
                  <Button
                    variant={theme === 'light' ? 'primary' : 'secondary'}
                    size="sm"
                    className="flex-1"
                    aria-pressed={theme === 'light'}
                    onClick={() => setTheme('light')}
                  >
                    <Sun className="size-4" aria-hidden="true" />
                    {t('theme.light')}
                  </Button>
                  <Button
                    variant={theme === 'dark' ? 'primary' : 'secondary'}
                    size="sm"
                    className="flex-1"
                    aria-pressed={theme === 'dark'}
                    onClick={() => setTheme('dark')}
                  >
                    <Moon className="size-4" aria-hidden="true" />
                    {t('theme.dark')}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t('account.securityTitle')}</CardTitle>
              <CardDescription>{t('account.email')}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4 break-all text-sm font-medium text-fg">{user.email ?? '—'}</p>
              <Button
                variant="danger"
                className="w-full"
                isLoading={isPending}
                loadingLabel={t('account.signOut')}
                onClick={() => void signOut()}
              >
                <LogOut className="size-4 rtl:rotate-180" aria-hidden="true" />
                {t('account.signOut')}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
