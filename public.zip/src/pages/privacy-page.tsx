import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { usePageTitle } from '@/lib/use-page-title';

const SECTIONS = [
  { titleKey: 'privacy.section1Title', bodyKey: 'privacy.section1Body' },
  { titleKey: 'privacy.section2Title', bodyKey: 'privacy.section2Body' },
  { titleKey: 'privacy.section3Title', bodyKey: 'privacy.section3Body' },
  { titleKey: 'privacy.section4Title', bodyKey: 'privacy.section4Body' },
  { titleKey: 'privacy.section5Title', bodyKey: 'privacy.section5Body' },
  { titleKey: 'privacy.section6Title', bodyKey: 'privacy.section6Body' },
  { titleKey: 'privacy.section7Title', bodyKey: 'privacy.section7Body' },
  { titleKey: 'privacy.section8Title', bodyKey: 'privacy.section8Body' },
  { titleKey: 'privacy.section9Title', bodyKey: 'privacy.section9Body' },
] as const;

export default function PrivacyPage() {
  const { t } = useTranslation();
  usePageTitle(t('privacy.title'));

  return (
    <div className="container max-w-3xl py-14 sm:py-20">
      <Badge variant="primary">
        <ShieldCheck className="size-3.5" aria-hidden="true" />
        {t('privacy.eyebrow')}
      </Badge>
      <h1 className="mt-4 text-display-sm">{t('privacy.title')}</h1>
      <p className="mt-3 text-sm text-muted">{t('privacy.updated')}</p>

      <Alert variant="warning" className="mt-7">
        {t('privacy.reviewNotice')}
      </Alert>

      <p className="mt-7 text-sm leading-7 text-muted sm:text-base">{t('privacy.intro')}</p>

      <div className="mt-10 space-y-9">
        {SECTIONS.map((section, index) => {
          const headingId = `privacy-section-${index + 1}`;
          return (
            <section key={section.titleKey} aria-labelledby={headingId}>
              <h2 id={headingId} className="text-lg font-bold text-fg sm:text-xl">
                {t(section.titleKey)}
              </h2>
              <p className="mt-2 text-sm leading-7 text-muted sm:text-base">{t(section.bodyKey)}</p>
            </section>
          );
        })}
      </div>

      <div className="mt-12 border-t border-line/70 pt-6">
        <Link
          to="/"
          className="inline-flex min-h-11 items-center gap-2 rounded-full px-4 text-sm font-semibold text-link transition-colors hover:bg-fg/5 hover:text-fg"
        >
          <ArrowLeft className="size-4 rtl:rotate-180" aria-hidden="true" />
          {t('common.backHome')}
        </Link>
      </div>
    </div>
  );
}
