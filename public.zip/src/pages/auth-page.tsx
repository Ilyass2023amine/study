import { Check, Sparkles } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link, Navigate, useLocation, useSearchParams } from 'react-router-dom';

import { BrandMark } from '@/components/brand/brand-mark';
import { PageLoader } from '@/components/layout/page-loader';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { ErrorState } from '@/components/ui/error-state';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/features/auth/auth-provider';
import { getSafeRedirect } from '@/features/auth/redirect';
import { SignInForm } from '@/features/auth/sign-in-form';
import { SignUpForm } from '@/features/auth/sign-up-form';
import { LanguageSwitcher } from '@/features/preferences/language-switcher';
import { ThemeToggle } from '@/features/preferences/theme-toggle';
import { configurationError } from '@/lib/env';
import { usePageTitle } from '@/lib/use-page-title';

export default function AuthPage() {
  const { t } = useTranslation();
  const { status } = useAuth();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  const mode = searchParams.get('mode') === 'signup' ? 'signup' : 'signin';

  usePageTitle(t(mode === 'signup' ? 'auth.signUpTab' : 'auth.signInTab'));

  if (status === 'loading') {
    return (
      <div className="min-h-dvh">
        <PageLoader />
      </div>
    );
  }

  if (status === 'authenticated') {
    return <Navigate to={getSafeRedirect(location.state)} replace />;
  }

  const handleModeChange = (value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'signup') {
      next.set('mode', 'signup');
    } else {
      next.delete('mode');
    }
    setSearchParams(next, { replace: true });
  };

  const showConfig = status === 'unconfigured' || Boolean(configurationError);

  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-hero-radial" />
      <div
        aria-hidden="true"
        className="aurora start-[10%] top-24 size-72 animate-soft-pulse bg-primary/25"
      />
      <div
        aria-hidden="true"
        className="aurora bottom-0 end-[0%] size-80 animate-soft-pulse bg-accent/10 [animation-delay:-5s]"
      />

      <header className="container relative flex h-16 items-center justify-between gap-2">
        <Link to="/" aria-label={t('app.name')} className="rounded-2xl">
          <span className="inline-flex sm:hidden">
            <BrandMark size={34} withWordmark={false} />
          </span>
          <span className="hidden sm:inline-flex">
            <BrandMark size={36} />
          </span>
        </Link>
        <div className="flex items-center gap-1">
          <LanguageSwitcher />
          <ThemeToggle />
        </div>
      </header>

      <main
        id="main-content"
        className="container relative grid flex-1 items-center gap-8 py-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16 lg:py-12"
      >
        <section className="max-w-xl">
          <Badge variant="accent">
            <Sparkles className="size-3.5" aria-hidden="true" />
            {t('app.name')}
          </Badge>
          <h1 className="mt-4 text-display-sm">{t('auth.sideTitle')}</h1>
          <p className="mt-4 text-base leading-7 text-muted">{t('auth.sideText')}</p>
          <ul className="mt-8 hidden space-y-3 lg:block">
            {[
              t('landing.safety.bullets.consent'),
              t('landing.safety.bullets.privacy'),
              t('landing.safety.bullets.control'),
            ].map((point) => (
              <li key={point} className="flex items-start gap-3 text-sm leading-6 text-muted">
                <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-success/15 text-success">
                  <Check className="size-3" aria-hidden="true" />
                </span>
                {point}
              </li>
            ))}
          </ul>
        </section>

        <section aria-label={t('nav.account')} className="mx-auto w-full max-w-md">
          <Card variant="glass" className="p-6 sm:p-8">
            {showConfig ? (
              <Alert variant="warning" title={t('auth.configTitle')}>
                <p>{t('auth.configBody')}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {['VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'].map((name) => (
                    <code
                      key={name}
                      className="rounded-md border border-line bg-canvas/60 px-2 py-1 font-mono text-[11px] text-fg"
                    >
                      {name}
                    </code>
                  ))}
                </div>
                {configurationError ? (
                  <p className="mt-3 text-xs text-muted">{configurationError}</p>
                ) : null}
                <p className="mt-3 text-xs">{t('auth.configDocs')}</p>
              </Alert>
            ) : status === 'error' ? (
              <ErrorState
                title={t('errors.unexpectedTitle')}
                description={t('auth.errors.generic')}
                retryLabel={t('common.retry')}
                onRetry={() => window.location.reload()}
              />
            ) : (
              <Tabs value={mode} onValueChange={handleModeChange}>
                <TabsList aria-label={t('nav.account')}>
                  <TabsTrigger value="signin">{t('auth.signInTab')}</TabsTrigger>
                  <TabsTrigger value="signup">{t('auth.signUpTab')}</TabsTrigger>
                </TabsList>
                <TabsContent value="signin">
                  <SignInForm />
                </TabsContent>
                <TabsContent value="signup">
                  <SignUpForm onShowSignIn={() => handleModeChange('signin')} />
                </TabsContent>
              </Tabs>
            )}

            <p className="mt-6 border-t border-line/60 pt-4 text-xs leading-5 text-muted">
              {t('auth.privacyNote')}{' '}
              <Link to="/privacy" className="font-semibold text-link hover:text-fg">
                {t('auth.privacyLink')}
              </Link>
            </p>
          </Card>

          <p className="mt-4 text-center">
            <Link
              to="/"
              className="inline-flex min-h-11 items-center rounded-full px-4 text-sm font-medium text-muted transition-colors hover:bg-fg/5 hover:text-fg"
            >
              {t('common.backHome')}
            </Link>
          </p>
        </section>
      </main>
    </div>
  );
}
