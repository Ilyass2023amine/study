import { useId } from 'react';

import { cn } from '@/lib/utils';

type ProgressTone = 'primary' | 'accent' | 'success';

const toneClasses: Record<ProgressTone, string> = {
  primary: 'bg-primary',
  accent: 'bg-accent',
  success: 'bg-success',
};

export interface ProgressBarProps {
  label: string;
  value: number;
  max?: number;
  showValue?: boolean;
  tone?: ProgressTone;
  valueText?: string;
  className?: string;
}

export function ProgressBar({
  label,
  value,
  max = 100,
  showValue = true,
  tone = 'primary',
  valueText,
  className,
}: ProgressBarProps) {
  const labelId = useId();
  const safeMax = max > 0 ? max : 100;
  const clamped = Math.min(Math.max(value, 0), safeMax);
  const percentage = Math.round((clamped / safeMax) * 100);

  return (
    <div className={cn('flex w-full flex-col gap-2', className)}>
      <div className="flex items-baseline justify-between gap-3">
        <span id={labelId} className="text-sm font-semibold text-fg">
          {label}
        </span>
        {showValue ? (
          <span className="text-xs font-semibold tabular-nums text-muted" aria-hidden="true">
            {percentage}%
          </span>
        ) : null}
      </div>
      <div
        role="progressbar"
        aria-labelledby={labelId}
        aria-valuemin={0}
        aria-valuemax={safeMax}
        aria-valuenow={clamped}
        aria-valuetext={valueText ?? `${percentage}%`}
        className="h-2.5 w-full overflow-hidden rounded-full bg-line/55"
      >
        <div
          className={cn(
            'h-full rounded-full transition-[width] duration-500 ease-smooth',
            toneClasses[tone],
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
