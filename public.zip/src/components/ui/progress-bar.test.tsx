import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { ProgressBar } from './progress-bar';

describe('ProgressBar', () => {
  it('clamps values and exposes accessible progress semantics', () => {
    render(<ProgressBar label="Weekly revision" value={12} max={10} />);

    const progress = screen.getByRole('progressbar', { name: 'Weekly revision' });
    expect(progress).toHaveAttribute('aria-valuemin', '0');
    expect(progress).toHaveAttribute('aria-valuemax', '10');
    expect(progress).toHaveAttribute('aria-valuenow', '10');
    expect(progress).toHaveAttribute('aria-valuetext', '100%');
  });

  it('uses a safe maximum when given zero', () => {
    render(<ProgressBar label="XP" value={25} max={0} showValue={false} />);

    expect(screen.getByRole('progressbar', { name: 'XP' })).toHaveAttribute('aria-valuemax', '100');
  });
});
