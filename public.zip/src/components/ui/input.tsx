import { AlertCircle } from 'lucide-react';
import { forwardRef, useId, type InputHTMLAttributes, type ReactNode } from 'react';

import { cn } from '@/lib/utils';

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
  error?: string;
  endAdornment?: ReactNode;
  containerClassName?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, hint, error, endAdornment, containerClassName, className, id, required, ...props },
  ref,
) {
  const generatedId = useId();
  const inputId = id ?? generatedId;
  const hintId = `${inputId}-hint`;
  const errorId = `${inputId}-error`;
  const describedBy = [hint ? hintId : null, error ? errorId : null].filter(Boolean).join(' ');

  return (
    <div className={cn('flex w-full flex-col gap-1.5', containerClassName)}>
      <label htmlFor={inputId} className="text-start text-sm font-semibold text-fg">
        {label}
        {required ? (
          <span className="text-danger" aria-hidden="true">
            {' '}
            *
          </span>
        ) : null}
      </label>
      <div className="relative">
        <input
          ref={ref}
          id={inputId}
          required={required}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy || undefined}
          className={cn(
            'min-h-11 w-full rounded-xl border border-line bg-canvas/60 px-3.5 py-2.5 text-sm text-fg shadow-sm transition-colors placeholder:text-muted/75 hover:border-fg/25 focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring/30 disabled:cursor-not-allowed disabled:opacity-60',
            error && 'border-danger/70 focus:border-danger focus:ring-danger/25',
            endAdornment && 'pe-12',
            className,
          )}
          {...props}
        />
        {endAdornment ? (
          <div className="absolute inset-y-0 end-1 flex items-center">{endAdornment}</div>
        ) : null}
      </div>
      {hint && !error ? (
        <p id={hintId} className="text-start text-xs leading-5 text-muted">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p
          id={errorId}
          className="flex items-start gap-1.5 text-start text-xs font-medium leading-5 text-danger"
        >
          <AlertCircle className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
          <span>{error}</span>
        </p>
      ) : null}
    </div>
  );
});
