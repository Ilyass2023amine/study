import { AlertCircle, CheckCircle2, Info, TriangleAlert } from 'lucide-react';
import type { ReactNode } from 'react';

import { cn } from '@/lib/utils';

type AlertVariant = 'info' | 'success' | 'warning' | 'error';

const styles: Record<AlertVariant, { wrapper: string; icon: string; Icon: typeof Info }> = {
  info: {
    wrapper: 'border-primary/25 bg-primary/8',
    icon: 'text-link',
    Icon: Info,
  },
  success: {
    wrapper: 'border-success/30 bg-success/8',
    icon: 'text-success',
    Icon: CheckCircle2,
  },
  warning: {
    wrapper: 'border-warning/30 bg-warning/8',
    icon: 'text-warning',
    Icon: TriangleAlert,
  },
  error: {
    wrapper: 'border-danger/30 bg-danger/8',
    icon: 'text-danger',
    Icon: AlertCircle,
  },
};

export interface AlertProps {
  variant?: AlertVariant;
  title?: string;
  children: ReactNode;
  className?: string;
}

export function Alert({ variant = 'info', title, children, className }: AlertProps) {
  const { wrapper, icon, Icon } = styles[variant];

  return (
    <div
      role={variant === 'error' ? 'alert' : 'status'}
      className={cn('flex items-start gap-3 rounded-xl border p-3.5 text-sm', wrapper, className)}
    >
      <Icon className={cn('mt-0.5 size-4 shrink-0', icon)} aria-hidden="true" />
      <div className="min-w-0 flex-1">
        {title ? <p className="font-semibold text-fg">{title}</p> : null}
        <div className={cn('leading-6 text-muted', title && 'mt-0.5')}>{children}</div>
      </div>
    </div>
  );
}
