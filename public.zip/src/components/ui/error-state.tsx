import { AlertTriangle, RefreshCw } from 'lucide-react';

import { cn } from '@/lib/utils';

import { Button } from './button';

export interface ErrorStateProps {
  title: string;
  description?: string;
  retryLabel?: string;
  onRetry?: () => void;
  className?: string;
}

export function ErrorState({
  title,
  description,
  retryLabel,
  onRetry,
  className,
}: ErrorStateProps) {
  return (
    <div
      role="alert"
      className={cn(
        'flex flex-col items-center justify-center gap-3 rounded-panel border border-danger/25 bg-danger/5 px-6 py-10 text-center',
        className,
      )}
    >
      <span className="bg-danger/12 flex size-12 items-center justify-center rounded-full text-danger">
        <AlertTriangle className="size-6" aria-hidden="true" />
      </span>
      <h2 className="text-lg font-bold text-fg">{title}</h2>
      {description ? <p className="max-w-md text-sm leading-6 text-muted">{description}</p> : null}
      {onRetry && retryLabel ? (
        <Button variant="secondary" size="sm" className="mt-2" onClick={onRetry}>
          <RefreshCw className="size-4" aria-hidden="true" />
          {retryLabel}
        </Button>
      ) : null}
    </div>
  );
}
