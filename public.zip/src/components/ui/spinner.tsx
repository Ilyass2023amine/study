import { Loader2 } from 'lucide-react';

import { cn } from '@/lib/utils';

const sizeClasses = {
  sm: 'size-4',
  md: 'size-6',
  lg: 'size-8',
};

export interface SpinnerProps {
  size?: keyof typeof sizeClasses;
  label?: string;
  className?: string;
}

export function Spinner({ size = 'md', label, className }: SpinnerProps) {
  return (
    <span
      role={label ? 'status' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      className={cn('inline-flex items-center justify-center text-link', className)}
    >
      <Loader2 className={cn('animate-spin', sizeClasses[size])} aria-hidden="true" />
      {label ? <span className="sr-only">{label}</span> : null}
    </span>
  );
}
