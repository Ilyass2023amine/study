import { useTranslation } from 'react-i18next';
import { Link, Outlet } from 'react-router-dom';

import { BrandMark } from '@/components/brand/brand-mark';
import { Avatar } from '@/components/ui/avatar';
import { useAuth } from '@/features/auth/auth-provider';
import { getUserDisplayName } from '@/features/auth/user';
import { LanguageSwitcher } from '@/features/preferences/language-switcher';
import { ThemeToggle } from '@/features/preferences/theme-toggle';

export function AppShell() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const displayName = getUserDisplayName(user);
  const year = new Date().getFullYear();

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-40 border-b border-line/60 bg-canvas/80 backdrop-blur-xl">
        <div className="container flex h-16 items-center justify-between gap-2">
          <Link to="/account" aria-label={t('app.name')} className="rounded-2xl">
            <span className="inline-flex sm:hidden">
              <BrandMark size={34} withWordmark={false} />
            </span>
            <span className="hidden sm:inline-flex">
              <BrandMark size={36} />
            </span>
          </Link>
          <div className="flex items-center gap-1">
            <LanguageSwitcher />
            <ThemeToggle />
            <Avatar name={displayName} size="sm" className="ms-1" />
          </div>
        </div>
      </header>

      <main id="main-content" className="container flex-1 py-8 sm:py-10">
        <Outlet />
      </main>

      <footer className="border-t border-line/70">
        <div className="container flex flex-col gap-2 py-6 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
          <p>{t('landing.footer.rights', { year })}</p>
          <Link to="/privacy" className="inline-flex min-h-11 items-center hover:text-fg">
            {t('landing.footer.privacy')}
          </Link>
        </div>
      </footer>
    </div>
  );
}
