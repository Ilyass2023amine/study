import { useTranslation } from 'react-i18next';

export function SkipLink() {
  const { t } = useTranslation();

  return (
    <a
      href="#main-content"
      className="sr-only rounded-full bg-primary px-5 py-3 font-semibold text-primary-fg focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-[80]"
    >
      {t('common.skipToContent')}
    </a>
  );
}
