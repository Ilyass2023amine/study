import { useTranslation } from 'react-i18next';

import { BrandMark } from '@/components/brand/brand-mark';
import { Spinner } from '@/components/ui/spinner';

export function PageLoader({ label }: { label?: string }) {
  const { t } = useTranslation();

  return (
    <div
      role="status"
      aria-live="polite"
      className="flex min-h-[60dvh] flex-col items-center justify-center gap-4 px-4 text-center"
    >
      <BrandMark size={52} withWordmark={false} />
      <Spinner size="lg" className="text-link" />
      <p className="text-sm text-muted">{label ?? t('common.loading')}</p>
    </div>
  );
}
