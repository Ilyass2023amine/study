import { useTranslation } from 'react-i18next';
import { Link, Outlet, useLocation } from 'react-router-dom';

import { BrandMark } from '@/components/brand/brand-mark';
import { buttonVariants } from '@/components/ui/button';
import { LanguageSwitcher } from '@/features/preferences/language-switcher';
import { ThemeToggle } from '@/features/preferences/theme-toggle';
import { useAuth } from '@/features/auth/auth-provider';
import { cn } from '@/lib/utils';

const SECTION_LINKS = [
  { href: '#features', labelKey: 'nav.features' },
  { href: '#how', labelKey: 'nav.how' },
  { href: '#safety', labelKey: 'nav.safety' },
] as const;

export function MarketingLayout() {
  const { t } = useTranslation();
  const { status } = useAuth();
  const { pathname } = useLocation();
  const isLanding = pathname === '/';
  const year = new Date().getFullYear();

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-40 border-b border-line/60 bg-canvas/80 backdrop-blur-xl">
        <div className="container flex h-16 items-center justify-between gap-2">
          <Link to="/" aria-label={t('app.name')} className="rounded-2xl">
            <span className="inline-flex sm:hidden">
              <BrandMark size={34} withWordmark={false} />
            </span>
            <span className="hidden sm:inline-flex">
              <BrandMark size={36} />
            </span>
          </Link>

          <nav aria-label={t('nav.label')} className="hidden items-center gap-1 lg:flex">
            {isLanding ? (
              SECTION_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="inline-flex min-h-11 items-center rounded-full px-3 text-sm font-medium text-muted transition-colors hover:bg-fg/5 hover:text-fg"
                >
                  {t(link.labelKey)}
                </a>
              ))
            ) : (
              <Link
                to="/"
                className="inline-flex min-h-11 items-center rounded-full px-3 text-sm font-medium text-muted transition-colors hover:bg-fg/5 hover:text-fg"
              >
                {t('common.backHome')}
              </Link>
            )}
          </nav>

          <div className="flex items-center gap-1">
            <LanguageSwitcher />
            <ThemeToggle />
            {status === 'authenticated' ? (
              <Link
                to="/account"
                className={cn(buttonVariants({ size: 'sm' }), 'hidden sm:inline-flex')}
              >
                {t('nav.account')}
              </Link>
            ) : (
              <>
                <Link
                  to="/auth"
                  className={cn(
                    buttonVariants({ variant: 'ghost', size: 'sm' }),
                    'hidden md:inline-flex',
                  )}
                >
                  {t('nav.signIn')}
                </Link>
                <Link
                  to="/auth?mode=signup"
                  className={cn(buttonVariants({ size: 'sm' }), 'hidden sm:inline-flex')}
                >
                  {t('nav.getStarted')}
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main id="main-content" className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t border-line/70 bg-surface/30">
        <div className="container flex flex-col gap-8 py-10">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-start">
            <div className="space-y-3">
              <BrandMark size={36} />
              <p className="max-w-sm text-sm leading-6 text-muted">{t('landing.footer.tagline')}</p>
            </div>
            <nav aria-label={t('nav.label')} className="flex flex-wrap items-center gap-1">
              <Link
                to="/privacy"
                className="inline-flex min-h-11 items-center rounded-full px-3 text-sm font-medium text-muted transition-colors hover:bg-fg/5 hover:text-fg"
              >
                {t('landing.footer.privacy')}
              </Link>
              {status !== 'authenticated' ? (
                <Link
                  to="/auth"
                  className="inline-flex min-h-11 items-center rounded-full px-3 text-sm font-medium text-muted transition-colors hover:bg-fg/5 hover:text-fg"
                >
                  {t('landing.footer.signIn')}
                </Link>
              ) : null}
              <LanguageSwitcher className="ms-1" />
            </nav>
          </div>
          <div className="flex flex-col gap-2 border-t border-line/60 pt-6 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
            <p>{t('landing.footer.rights', { year })}</p>
            <Link to="/privacy" className="inline-flex min-h-11 items-center hover:text-fg">
              {t('landing.footer.privacy')}
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
