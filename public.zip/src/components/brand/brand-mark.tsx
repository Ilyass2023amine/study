import { useId } from 'react';

import { cn } from '@/lib/utils';

export interface BrandMarkProps {
  size?: number;
  withWordmark?: boolean;
  className?: string;
}

export function BrandMark({ size = 38, withWordmark = true, className }: BrandMarkProps) {
  const rawId = useId();
  const id = rawId.replace(/:/g, '');
  const backgroundId = `brand-bg-${id}`;
  const ringId = `brand-ring-${id}`;
  const glowId = `brand-glow-${id}`;

  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 512 512"
        aria-hidden="true"
        className="shrink-0 drop-shadow-[0_6px_20px_rgba(124,92,255,0.35)]"
      >
        <defs>
          <linearGradient id={backgroundId} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#101A35" />
            <stop offset="1" stopColor="#050914" />
          </linearGradient>
          <linearGradient id={ringId} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#B9A6FF" />
            <stop offset="1" stopColor="#67E8F9" />
          </linearGradient>
          <radialGradient id={glowId} cx="0.3" cy="0.2" r="0.8">
            <stop offset="0" stopColor="#7C5CFF" stopOpacity="0.75" />
            <stop offset="1" stopColor="#7C5CFF" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="512" height="512" rx="112" fill={`url(#${backgroundId})`} />
        <rect width="512" height="512" rx="112" fill={`url(#${glowId})`} />
        <g transform="rotate(-24 256 256)">
          <ellipse
            cx="256"
            cy="256"
            rx="174"
            ry="95"
            fill="none"
            stroke={`url(#${ringId})`}
            strokeWidth="10"
            opacity="0.8"
          />
          <circle cx="410" cy="205" r="17" fill="#22D3EE" />
          <circle cx="74" cy="306" r="14" fill="#C4B5FD" />
        </g>
        <path
          d="M256 136c15 68 41 96 120 120-79 24-105 52-120 120-15-68-41-96-120-120 79-24 105-52 120-120Z"
          fill="#FCFDFF"
        />
      </svg>
      {withWordmark ? (
        <span
          dir="ltr"
          className="font-display text-lg font-extrabold tracking-tight text-fg [font-family:'Plus_Jakarta_Sans_Variable',sans-serif]"
        >
          Study<span className="text-link">Verse</span>
        </span>
      ) : (
        <span className="sr-only">StudyVerse</span>
      )}
    </span>
  );
}
