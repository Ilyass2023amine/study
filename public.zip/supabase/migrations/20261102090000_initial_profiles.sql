-- Phase 0: profile foundation for StudyVerse.
-- Every profile row is created from auth.users by a security-definer trigger.
-- RLS and column-level grants keep students scoped to their own row and prevent
-- self-service role elevation.

begin;

create type public.user_role as enum ('student', 'parent', 'teacher', 'admin');
create type public.app_language as enum ('fr', 'ar', 'dar');

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  role public.user_role not null default 'student',
  display_name text not null,
  preferred_language public.app_language not null default 'fr',
  onboarded_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_display_name_length
    check (char_length(btrim(display_name)) between 2 and 60)
);

comment on table public.profiles is
  'Minimal account profile. Learning data, consent and parent links are added in later phases.';
comment on column public.profiles.role is
  'Server-controlled role. Authenticated users have no UPDATE grant on this column.';

alter table public.profiles enable row level security;

create policy profiles_select_own
  on public.profiles
  for select
  to authenticated
  using ((select auth.uid()) = id);

create policy profiles_update_own
  on public.profiles
  for update
  to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);

revoke all on table public.profiles from anon, authenticated;
grant select on table public.profiles to authenticated;
grant update (display_name, preferred_language, onboarded_at)
  on table public.profiles
  to authenticated;

create function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at
  before update on public.profiles
  for each row
  execute function public.set_updated_at();

create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  requested_name text;
  safe_name text;
begin
  requested_name := coalesce(
    new.raw_user_meta_data ->> 'display_name',
    split_part(coalesce(new.email, ''), '@', 1)
  );
  safe_name := left(btrim(coalesce(requested_name, '')), 60);

  if char_length(safe_name) < 2 then
    safe_name := 'Élève';
  end if;

  insert into public.profiles (id, display_name)
  values (new.id, safe_name)
  on conflict (id) do nothing;

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.set_updated_at() from public, anon, authenticated;

-- Backfill accounts created before this migration was applied.
insert into public.profiles (id, display_name)
select
  users.id,
  case
    when char_length(btrim(coalesce(users.raw_user_meta_data ->> 'display_name', ''))) between 2 and 60
      then btrim(users.raw_user_meta_data ->> 'display_name')
    else 'Élève'
  end
from auth.users as users
on conflict (id) do nothing;

commit;
