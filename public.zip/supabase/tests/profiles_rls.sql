-- Run with the Supabase CLI: supabase test db
-- Verifies the profile trigger, default values, RLS and column-level grants.
begin;

create extension if not exists pgtap with schema extensions;

select plan(9);

insert into auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at
)
values
  (
    '00000000-0000-0000-0000-000000000000',
    '11111111-1111-4111-8111-111111111111',
    'authenticated',
    'authenticated',
    'sara@example.test',
    'not-used-in-tests',
    now(),
    '{"provider":"email","providers":["email"]}',
    '{"display_name":"Sara"}',
    now(),
    now()
  ),
  (
    '00000000-0000-0000-0000-000000000000',
    '22222222-2222-4222-8222-222222222222',
    'authenticated',
    'authenticated',
    'yassine@example.test',
    'not-used-in-tests',
    now(),
    '{"provider":"email","providers":["email"]}',
    '{"display_name":"Yassine"}',
    now(),
    now()
  );

select is(
  (
    select count(*)::int
    from public.profiles
    where id in (
      '11111111-1111-4111-8111-111111111111',
      '22222222-2222-4222-8222-222222222222'
    )
  ),
  2,
  'the auth trigger creates one profile per user'
);

select is(
  (
    select display_name
    from public.profiles
    where id = '11111111-1111-4111-8111-111111111111'
  ),
  'Sara',
  'the trigger copies display_name from user metadata'
);

select is(
  (
    select role::text
    from public.profiles
    where id = '11111111-1111-4111-8111-111111111111'
  ),
  'student',
  'new profiles receive the student role'
);

select set_config(
  'request.jwt.claims',
  '{"sub":"11111111-1111-4111-8111-111111111111","role":"authenticated"}',
  true
);
set local role authenticated;

select results_eq(
  'select count(*)::int from public.profiles',
  array[1],
  'a student sees only their own profile'
);

update public.profiles
set display_name = 'Sara Updated'
where id = '11111111-1111-4111-8111-111111111111';

select results_eq(
  $$
    select display_name
    from public.profiles
    where id = '11111111-1111-4111-8111-111111111111'
  $$,
  array['Sara Updated'],
  'a student can update their own display name'
);

select throws_ok(
  $$
    update public.profiles
    set role = 'admin'
    where id = '11111111-1111-4111-8111-111111111111'
  $$,
  '42501',
  null,
  'a student cannot elevate their own role'
);

select results_eq(
  $$
    with changed as (
      update public.profiles
      set display_name = 'Hacked'
      where id = '22222222-2222-4222-8222-222222222222'
      returning 1
    )
    select count(*)::int from changed
  $$,
  array[0],
  'a student cannot update another profile'
);

reset role;

select is(
  (
    select display_name
    from public.profiles
    where id = '22222222-2222-4222-8222-222222222222'
  ),
  'Yassine',
  'another profile is unchanged'
);

select set_config('request.jwt.claims', '{"role":"anon"}', true);
set local role anon;

select throws_ok(
  'select * from public.profiles',
  '42501',
  null,
  'anonymous users have no profile access'
);

reset role;

select * from finish();

rollback;
